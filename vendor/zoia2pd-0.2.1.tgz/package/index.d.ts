/**
 * Convert a 32,768-byte ZOIA .bin file to Pure Data patch text synchronously.
 * Accepts bytes, not a filename or File. Use await file.arrayBuffer() in a browser.
 * Does not mutate the input. Throws Error for invalid input.
 * Conversion limitations and skipped connections appear as comments in the Pd text.
 */
export declare function convertBinary(bytes: ArrayBuffer | Uint8Array): string;

export type PreviewSupport =
  | { status: "live" }
  | { status: "approximate"; reason: string };

export interface PreviewModule {
  index: number;
  typeId: number;
  typeName: string;
  name: string | null;
  pageIndex: number;
  pageName: string | null;
  colorIndex: number;
}

export interface PreviewStar {
  blockIndex?: number;
  midiCc: number | null;
}

export interface PreviewValueSpec {
  min: number;
  max: number;
  step: number;
  unit: "normalized" | "raw-connection-strength";
  curve: "linear" | "decibel-amplitude";
}

interface PreviewControlBase {
  kind: string;
  id: string;
  label: string;
  support: PreviewSupport;
}

export interface PreviewParameterControl extends PreviewControlBase {
  kind: "parameter";
  module: PreviewModule;
  blockIndex: number;
  parameterIndex: number;
  blockName: string;
  star: PreviewStar;
  baseValue: number;
  savedRawValue: number | null;
  valueSpec: PreviewValueSpec;
  receiver: string;
  baseFeedback: string;
  effectiveFeedback: string;
}

export interface PreviewButtonControl extends PreviewControlBase {
  kind: "pushbutton" | "stompswitch" | "euro-pushbutton";
  module: PreviewModule;
  action: "momentary" | "latching";
  normal: 0 | 1;
  stars: PreviewStar[];
  assignment?: "left" | "middle" | "right" | "external";
  button?: 1 | 2;
  receiver: string;
  stateFeedback: string;
}

export interface PreviewUiButtonControl extends PreviewControlBase {
  kind: "ui-button";
  module: PreviewModule;
  blockIndex: 0;
  outputEnabled: boolean;
  rangeMode: "basic" | "extended";
  star?: PreviewStar;
  baseValue: number;
  savedRawValue: number | null;
  receiver: string;
  baseFeedback: string;
  effectiveFeedback: string;
}

export interface PreviewKeyboardKey {
  index: number;
  label: string;
  savedRawValue: number | null;
  noteValue: number;
  noteName: string | null;
  star?: PreviewStar;
}

export interface PreviewKeyboardControl extends PreviewControlBase {
  kind: "keyboard";
  module: PreviewModule;
  count: number;
  keys: PreviewKeyboardKey[];
  receiver: string;
  noteFeedback: string;
  gateFeedback: string;
  triggerFeedback: string;
  overlapPolicy: "highest-note";
}

export interface PreviewConnectionControl extends PreviewControlBase {
  kind: "connection";
  connectionIndex: number;
  star: PreviewStar;
  source: { moduleIndex: number; blockIndex: number; blockName: string; pageIndex: number };
  destination: { moduleIndex: number; blockIndex: number; blockName: string; pageIndex: number };
  signalType: "cv" | "audio";
  initialStrength: { raw: number; decibels: number; linearGain: number };
  valueSpec: PreviewValueSpec;
  receiver: string;
  strengthFeedback: string;
  gainFeedback: string;
}

export type PreviewControl = PreviewParameterControl | PreviewButtonControl |
  PreviewUiButtonControl | PreviewKeyboardControl | PreviewConnectionControl;

export interface PreviewWarning {
  code: "conversion-warning" | "unsupported-star-target" | "unsupported-bridge";
  severity: "warning";
  message: string;
  moduleIndex?: number;
  blockIndex?: number;
  connectionIndex?: number;
  bridge?: "midi" | "hardware" | "audio-input" | "sampler";
}

export interface BrowserConversionV1 {
  apiVersion: 1;
  pdText: string;
  controls: PreviewControl[];
  warnings: PreviewWarning[];
}

/** Convert bytes into a libpd-ready patch plus Browser Preview control manifest. */
export declare function convertBinaryForBrowser(
  bytes: ArrayBuffer | Uint8Array,
): BrowserConversionV1;
