# ZoiaPD

**ZOIA Binary Patch to PureData Converter**

ZoiaPD converts [Empress ZOIA](https://empresseffects.com/products/zoia) binary patch files (`.bin`, 32 KB) into [PureData](https://puredata.info/) (`.pd`) patch files. It parses all 6 sections of the ZOIA binary format (header, modules, connections, page names, starred elements, module colors) and maps ZOIA modules to their closest PureData vanilla equivalents.

## Features

- Defines all 110 ZOIA module types (IDs 0–109), with firmware 5.41 options and active-block layouts
- Explicit Pd mappings for IDs 0–107, ranging from basic objects to incomplete DSP subpatches; IDs 108–109 currently use placeholders
- Converts module connections to Pd patch cords, with connection-strength scaling
- Connection strength → gain objects, CV normalization with `clip`/`clip~`
- Starred element annotations with MIDI CC assignments
- Interactive, non-interactive, and batch conversion modes

## Module catalog and implementation plan

Definitions track [zoia-explorer-v2 revision e02be417](https://github.com/laurentgratton/zoia-explorer-v2/commit/e02be41762eee2ea1ae2c6971ec69bb38c07fb3a)
(2026-09-03), including MIDI Pitch Bend Out (108), MIDI Pressure Out (109),
updated Sampler/Sequencer/mixer layouts, and sequential visible parameter indices.
Catalog coverage does **not** mean complete DSP or saved-state support.

See the [Pd module-group roadmap](docs/pd-module-roadmap.md) for the current
implementation gaps, group contracts, seven module-family waves covering all
110 IDs, and acceptance tests. The first milestone is correct ports, saved
parameters, isolated instance state, and a headless Pd verification harness.

## Requirements

- [Clojure](https://clojure.org/guides/install_clojure) 1.12+ with tools.deps

## Build & Run

No compilation step required — Clojure runs directly from source.

### Interactive mode (default)

```bash
clj -M -m zoia2pd.core patch.bin
```

Loads the patch and presents a menu:
- **[I]nspect** — display patch summary (modules, connections, pages, starred elements)
- **[C]onvert** — convert to `.pd` and write to disk
- **[Q]uit**

### Non-interactive conversion

```bash
clj -M -m zoia2pd.core -n patch.bin output.pd
```

If no output path is given, uses the input filename with `.pd` extension:

```bash
clj -M -m zoia2pd.core -n patch.bin
# Writes patch.pd
```

### Batch conversion

Convert all valid `.bin` files (32768 bytes) in a directory:

```bash
clj -M -m zoia2pd.core -b patches/ -o pd-output/
```

If `--output-dir` is omitted, `.pd` files are written alongside the `.bin` files.

### Help

```bash
clj -M -m zoia2pd.core --help
```

## Running Tests

```bash
clj -X:test
```

Integration tests in `test/zoia2pd/integration_test.clj` will automatically discover `.bin` patches in `resources/test-patches/` and test parsing + conversion. If no patches are present, those tests skip gracefully.

## Browser / ES module library

The ClojureScript library shares its parser, module recipes, layout and Pd emitter
with the JVM CLI. Build it at the repository root using Node/npm and Java 17+:

```bash
npm ci
npm run build
```

This creates the optimized, self-contained `dist/index.js` ES module. The pinned
shadow-cljs version supports Java 17. Java and Clojure tooling are **build-time
only**; the output needs no backend, Node polyfills, or runtime npm dependencies.

```js
import { convertBinary } from './dist/index.js';

// file is a browser File selected by the host application.
const pdText = convertBinary(await file.arrayBuffer());
// Host code can download this text or pass it to libpd-wasm.
const pdFile = new Blob([pdText], { type: 'text/plain;charset=utf-8' });
```

`convertBinary(bytes: ArrayBuffer | Uint8Array): string` is synchronous and does
not mutate input. Typed-array slices (including Node Buffers) respect their offset
and length. Pass the bytes of one 32,768-byte `.bin`, not a filename or `File`.
Invalid sizes and malformed records throw `Error` (`TypeError` for unsupported
input types). Existing unsupported-module, saved-state and skipped-connection
warnings are embedded in the returned Pd comments; successful conversion does
not imply firmware-equivalent sound or complete saved-parameter restoration.

The module also works in module workers. It performs no file access, network
requests, DOM operations, or audio initialization. File selection, downloads,
playback and UI remain the host's responsibility. In zoia-explorer-v2, pass the
stored binary buffer, or serialize the edited patch before conversion.

For another application, run `npm pack`, install the resulting local `.tgz`, and
use `import { convertBinary } from 'zoia2pd'`. The package includes TypeScript
declarations and built JavaScript. It is marked private to prevent accidental
registry publication. Alternatively, copy `dist/index.js` into static assets.

```bash
npm test       # CLJS binary tests, optimized build, and JVM/ESM parity tests
clojure -X:test # Existing JVM and available native Pd tests
```

The parity tests require the Clojure CLI and cover all 110 default module types,
connected graphs, feedback, saved-data padding, and unsigned values. Floating
point text formatting can differ between JavaScript and the JVM. Cycle traversal
uses sorted module indices so both runtimes reject the same CV back edges.

For browser verification, serve the repository root over HTTP, then run
`node test/browser-esm.mjs` with `agent-browser` installed. Set `ESM_TEST_URL` if
the server is not on port 8080. This checks browser File input, slice handling,
errors, module-worker execution, and parity with the Node ES-module output.

## Browser patch tester

The tester uses pinned **libpd-wasm 0.1.6**, running Pd's engine rather than
compiling a WebPd-specific graph. Install Node/npm and Python 3, then:

```bash
cd resources/tester
npm ci
npm start
```

Open the server on port 8080 locally (use HTTPS when hosting remotely). Select a
self-contained `.pd` patch and click **Play**; there is no compile step and patch
contents stay in the browser. **Stop** pauses, **Play** resumes, and selecting a
new file closes the old engine. `resources/tester/smoke.pd` is a low-level stereo
test patch; start at low volume. Serve the installed `node_modules` directory
alongside `index.html`, preserving the packages' license notices.

Output is stereo. Microphone input, MIDI devices, external abstraction files and
sample-file uploads are not connected. Browser MIDI is explicitly deferred in the
[roadmap](docs/pd-module-roadmap.md#browser-runtime-and-deferred-midi-integration).
The runtime replacement does not complete the generator's existing DSP stubs.
Inspect the Pd log for creation/connection errors even when a patch opens.

With the tester running and `agent-browser`/Chromium installed, run from the
repository root:

```bash
node test/browser-smoke.mjs
```

This measures distinct left/right audio levels and checks embedded subpatches,
`expr~`, array and `sigmund~` creation, stop/resume, replacement and error recovery.
Set `TESTER_URL` to test a different server URL.

### Generated-patch regression checks

`clj -X:test` also runs desktop Pd DSP tests when `/usr/bin/pd` is installed
(`sudo apt-get install puredata-core` on Debian). Those tests explicitly skip
when Pd is absent. They measure mono/stereo VCA and output gain, and check delay
isolation across module instances and simultaneously open patches.

To exercise the generator through the browser tester, with its server running:

```bash
clojure -Sdeps '{:paths ["src" "resources" "test"]}' -M \
  -m zoia2pd.pd.runtime-test /tmp/generated-audio.pd
PD_FIXTURE=/tmp/generated-audio.pd PD_AMPLITUDES='[0.02,0.2]' \
  node test/browser-smoke.mjs
```

This fixture converts two oscillators, identical delay modules, a stereo VCA,
gain-controlled output and two Value modules whose held CV outputs sum to 0.5.
Explicit `:base-values` initialize Pd-native controls;
it does not test restoration of ZOIA saved parameters. Expected sine amplitudes
are 0.1 × 0.5 × 0.4 = 0.02 on the left and 1 × 0.5 × 0.4 = 0.2 on the right.
Open the same generated `.pd` in desktop Pd or the browser to inspect it.

Audio Output gain defaults to unity and VCA gain to zero until control messages
arrive; both currently use linear amplitude, not a verified ZOIA gain curve.
Conversion warnings identify skipped cords and placeholders in both the CLI
summary and exported patch. The wired count excludes skipped connections;
warnings are not yet a complete audit of all unsupported module options.

Programmatic conversion accepts `:base-values` keyed by an active CV input name,
for example `{:type-id 45 :options [] :base-values {"value" 0.1}}`. Incoming
weighted modulation is added to this base without global clipping. Unknown names,
audio ports and non-finite values are rejected. This is not a decoder for raw
ZOIA parameters or a browser parameter editor. Without an explicit base, existing
recipe defaults apply until an input arrives.

## Project Structure

```
src/zoia2pd/
├── core.clj              # CLI entry point and argument parsing
├── api.cljs              # convertBinary ES-module export
├── binary/
│   ├── parser.cljc       # Shared binary parser (all 6 sections)
│   ├── types.clj         # JVM ByteBuffer reader
│   └── types.cljs        # Browser DataView reader
├── modules/
│   ├── definitions.cljc  # All 110 ZOIA module type definitions + calcBlocks
│   └── mapping.cljc      # ZOIA module → PureData object mapping
├── pd/
│   ├── emitter.cljc      # PureData .pd text file generation
│   └── layout.cljc       # Grid position → canvas coordinate layout
└── cli/
    ├── inspect.clj       # Patch inspection and summary display
    └── interactive.clj   # Interactive REPL loop
```

## Known Limitations

### Placeholder Modules

All MIDI and physical-host modules remain deferred, with typed inert boundaries.
Selected recording/sequencer modes are also explicitly unsupported.
Conversion counts unsupported modes using the selected options, not just the type
ID. The placeholder count is not a fidelity score.

### Other Limitations

- Audio, control, effects and recording families now emit embedded primitive recipes. Their coverage and numerical verification are still incomplete; see the [implementation status](docs/pd-module-roadmap.md#current-implementation-status).
- Sampler overdub/punch-in and advanced sequencer modes remain unsupported. Granular uses a bounded, deterministic Pd approximation; its tap-labelled controls retain CV semantics until firmware timing is known. Reverse Delay tap mode measures literal 20–4000 ms intervals, but its firmware ratio curve remains unknown. Rhythm retains only its last recorded interval. Other optional controls still need per-mode acceptance tests.
- Binary parameters, module version, names and padded saved data are decoded separately against the pinned explorer contract. Restoring sequencer pages and loading sampler files remain unimplemented. Saved VCA/Audio Output gains produce warnings rather than guessed initialization; their transfer functions are still unverified. See the [binary audit](docs/binary-contract-audit.md).
- CV uses numeric messages and a provisional 1 ms logical tick. No global normalization is applied. Instantaneous CV feedback is rejected rather than risking an infinite event loop.
- Filter/effect models are labelled sonic approximations; firmware-equivalent curves, timing and sound remain unverified.

## License

Private project — not yet published.
